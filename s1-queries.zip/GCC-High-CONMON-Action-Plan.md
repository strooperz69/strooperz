# GCC High tenant CONMON

Hand this to a Cybersecurity Engineer. SentinelOne Data Lake is the SIEM/XDR. Microsoft Purview and Log Analytics exist as fallbacks only.

Organization is CMMC Level 2 certified. This plan keeps L2 monitoring honest and leaves a clean on-ramp to CMMC Level 3. It does not try to watch every tenant change.

Copilot user, file, AppIdentity, and keyword usage queries are already in production. That work satisfied an audit question. Do not rebuild it. It comes back in Wave 3.

Global Admin activity that showed up in the tenant is treated as **oversight** (match to a change ticket). It is not an incident unless the ticket or the change itself says otherwise.

---

## 1. Tools and search order

Use this order every time. Do not start in Purview.

1. **SentinelOne Event Search (PowerQuery)**  
   If the event is in the lake, CONMON lives here (saved query, STAR/scheduled rule, dashboard).
2. **Event Hub (the one IT stood up)**  
   If S1 is empty, the record may still be on the hub. Confirm the publisher is sending and that S1 is listening.
3. **Custom parser**  
   One hub carries mixed Microsoft payloads (UAL Copilot, UAL Exchange, Entra audit, Azure Activity, and so on). S1 will not query a field until a parser (or `unmapped.*` / `message` / `RawEventData`) exposes it. A missing field is often a parser gap, not a Microsoft gap.
4. **Log Analytics**  
   Use only to prove Microsoft emitted the event (OfficeActivity, AuditLogs, SigninLogs, AzureActivity). Do not build the CONMON program here.
5. **Purview audit search**  
   Last resort to prove the workload logged. Do not operate from it.

If the event is in Purview or Log Analytics but not in S1, the finding is **ingest or parser**, not "we do not have logs."

---

## 2. Event Hub and parsers (read this first)

IT sent multiple Microsoft log types through **one** Event Hub. That is a valid GCC High pattern (Management API / diagnostics to Event Hubs, S1 as the consumer). It has a cost:

- S1 `dataSource.name` may be one name (`Azure`) for everything, or IT/S1 may have split parsed sources (`Microsoft Copilot`, later Entra, and so on).
- Copilot usage already showed this: first source was `Azure` with JSON in `message`; later a parsed source `Microsoft Copilot` with `LLMEventData.*` and `RawEventData.ClientIP`.
- Defender/MCAS names (`CloudAppEvents.City`) will 503/zero in PowerQuery on this lake. Use fields you have opened on a real event.
- Nested arrays flatten in the UI as `Something[0].Name`. PowerQuery does not accept `[0]`. Use `Something[*].Name` and `expand()`, or the zip/split pattern already proven on Copilot files.
- `tag != 'logVolume'` belongs in the initial filter so ingest-metering rows do not fake a live source.
- Do not use `| columns *`. Do not put `= *` inside `let`. `* contains` only before the first pipe.

**Parser rule for Wave 1:** do not wait for a perfect Entra parser. Hunt with `* contains` and `message` / `unmapped.*` / `RawEventData.*` / `ActorName` the same way Copilot was proven. File a parser story only after you know which JSON keys are stable.

---

## 3. What this CONMON covers

Four planes. Wave 1 is plane A only.

| Plane | Meaning | Wave |
|---|---|---|
| A. Identity / privilege | GA, PRA, PIM assign/activate, break-glass | 1 then 2 |
| B. Apps and consent | Admin consent, Copilot plugins, collector app | 2 (thin) then 3 |
| C. Workload admin | Copilot settings, EXO, SPO, labels | 3 and later |
| D. Pipeline | Hub dest, S1 silence, parser health | 1 (discover) then 2 alerts D/E |

CMMC L2 IDs this plan actually touches: 3.1.5, 3.1.6, 3.3.1, 3.3.2, 3.12.3. L3 (32 CFR 170.14, selected 800-172) is Wave 5: 24/7 SOC, hunting, org-owned devices, annual pentest. Do not start L3 until Waves 1-2 have been quiet for 30 days.

Authority to cite if GRC asks (do not turn these into reading homework): CMMC L2 = NIST SP 800-171 Rev 2; CMMC L3 = 32 CFR 170.14 Table 1; Microsoft Entra CMMC L2 identity logging; Microsoft Entra PIM security operations; CISA SCuBA M365 (GA activation shall alert, no standing highly privileged roles). FedRAMP ConMon is Microsoft's CSP program, not this tenant.

---

## 4. Waves (engineer stops at the end of each)

| Wave | Goal | Stop when |
|---|---|---|
| 0 | Copilot usage CONMON | Already done |
| **1** | **Entra privileged change visible in S1** | Named source + query reproduces known GA work |
| 2 | Eight alerts only (see section 8) | STAR/scheduled rules for A-H |
| 3 | Rest of Copilot CONMON (admin, silence, consent, CUI names) | When that audit cycle is due |
| 4 | Inventory other lake sources; quarterly ScubaGear | One-page source table |
| 5 | L3 hunting, 24/7 ownership of A-H, org-owned device | After 30 days of boring Wave 2 |

---

## 5. Wave 1 playbook

Owner: Cybersecurity Engineer. Time: about one to two weeks. Helper: whoever owns the Event Hub and S1 parsers (IT). GRC: one oversight sentence in the runbook.

### Step 0. Baseline (30 minutes)

Copy from the Copilot work so you do not relearn it:

- Event Search time picker is the window. Do not hardcode time in the query.
- Initial filter always includes `tag != 'logVolume'`.
- Save every working query as a named Event Search (and later STAR).
- Known-good Copilot source for usage: `dataSource.name = 'Microsoft Copilot'`.
- Known-good older UAL blob source: `dataSource.name = 'Azure'`. Entra may be either, or a third name. Prove it. Do not guess.

### Step 1. Is Entra audit in S1 at all?

Paste in Event Search. Widen the picker to 7 days (or whatever window held the known Global Admin change).

```
tag != 'logVolume'
dataSource.name = *
(
  * contains 'Global Administrator'
  OR * contains 'Privileged Role Administrator'
  OR * contains 'Add member to role'
  OR * contains 'Add eligible member to role'
  OR * contains 'Privileged Identity Management'
)
| group n=count() by dataSource.name
| sort -n
```

| Result | Meaning | Next |
|---|---|---|
| Named source with n > 0 | Entra (or UAL wrapping Entra) is in the lake | Step 2 using that exact `dataSource.name` |
| Only a **null** source | S1 Event Search audit of your own hunt, not tenant logs | Treat as empty. Go Step 1b |
| Zero rows | Not in the lake under those strings | Step 1b |

**Step 1b. Not in S1.** Work backward. Do not open Purview yet.

1. Event Hub: is there a diagnostic or Management API publisher for **Entra AuditLogs** (and preferably Sign-in) on **this** hub? If IT only subscribed Audit.General (M365 UAL), Entra directory audit is a different stream. That is the usual miss.
2. S1: is the hub consumer healthy? Copilot still flowing is not proof Entra is on the same subscription.
3. Parser: if hub metrics show messages but S1 has no searchable `Global Administrator`, the payload is landing as opaque `message`. Open one raw event. If the JSON has `activityDisplayName` / `loggedByService` / `category` = RoleManagement, file a parser for Entra audit. Until then, `* contains 'Global Administrator'` on `message` is a valid Wave 1 query.
4. Log Analytics: only to answer "did Entra emit it?" Table is typically `AuditLogs`. If LA has the GA event and the hub has it, S1/parser is the gap. If LA does not have it, Entra diagnostic settings are the gap.
5. Purview: only if you need to prove a **M365 workload** audit record exists. It will not be a good Entra PIM console.

Write down: `dataSource.name` (or "missing"), hub subscription (yes/no), parser (yes/no), LA (yes/no). That row is the Wave 1 evidence.

### Step 2. Reproduce the known Global Admin change

Replace `Azure` with the name from Step 1.

```
tag != 'logVolume'
dataSource.name = 'Azure'
(
  * contains 'Global Administrator'
  OR * contains 'Privileged Role Administrator'
)
| let Actor = ActorName ? ActorName : (UserId ? UserId : unmapped.initiatedBy)
| let Op = Operation ? Operation : (activityDisplayName ? activityDisplayName : unmapped.activityDisplayName)
| filter !isempty(Op)
| columns timestamp, Actor, Op
| sort -timestamp
```

Done when this list includes the Global Admin work you already know about, in the same time window.

If `Actor` or `Op` is empty, open **one** event and put the real field in the `let` lines (`RawEventData.activityDisplayName`, `unmapped.activityDisplayName`, and so on). Do not use `CloudAppEvents.*`. Do not use `= *` inside `let`.

### Step 3. Count by actor (oversight, not IR)

```
tag != 'logVolume'
dataSource.name = 'Azure'
(
  * contains 'Global Administrator'
  OR * contains 'Privileged Role Administrator'
)
| let Actor = ActorName ? ActorName : (UserId ? UserId : unmapped.initiatedBy)
| let Op = Operation ? Operation : (activityDisplayName ? activityDisplayName : unmapped.activityDisplayName)
| filter !isempty(Op)
| group n=count() by Actor, Op
| sort -n
```

Hand this to GRC: who touched GA/PRA, how often, which operation. They match tickets.

### Step 4. PIM posture (30 minutes, Entra portal or export)

Not an S1 query. Spreadsheet columns:

- Role (Global Administrator, Privileged Role Administrator)
- Account UPN
- Eligible vs standing **Active**
- Cloud-only vs synced
- Break-glass? (yes/no)

L2 expectation: humans are eligible + approval, not standing active. Break-glass is documented, cloud-only, and will get an alert in Wave 2.

### Step 5. Parser ticket (only if needed)

If Step 2 only works via `* contains` on `message`, open a parser request:

- Sample JSON (redact UPNs if required)
- Keys you need as scalars: `activityDisplayName`, `initiatedBy`, `targetResources` (role name), `result`, `operationType`
- Source name to keep stable (do not rename `Azure` under Copilot queries)

Wave 1 **does not block** on the parser. The `* contains` query is the CONMON control until scalars exist.

### Step 6. Runbook sentence (GRC)

"Global Administrator and Privileged Role Administrator activity in SentinelOne is reviewed against change tickets. Presence of the event is not an incident."

### Wave 1 done

- [ ] Entra privileged strings exist under a named `dataSource.name`, or a written ingest gap with an IT ticket
- [ ] Known GA change is visible in S1 for that window
- [ ] Saved query (list + group)
- [ ] PIM eligible vs active spreadsheet
- [ ] Oversight sentence in the runbook
- [ ] Parser ticket only if still message-only

**Stop.** Do not add Exchange, Copilot plugins, or Netskope. Wave 2 is the eight alerts.

---

## 6. Wave 2 (preview so Wave 1 stays in bounds)

Do not build these until Wave 1 is checked off. All of them are S1 STAR/scheduled, `tag != 'logVolume'`, time window on the rule.

| ID | Alert | Plane |
|---|---|---|
| A | Global Admin activation | A |
| B | Privileged Role Admin assign/activate | A |
| C | Break-glass UPN any sign-in | A |
| D | Tenant log pipeline changed (hub / diagnostic) | D |
| E | Expected S1 source silent in business hours | D |
| F | Admin consent or app role on Copilot / ActivityFeed.Read | B |
| G | Conditional Access policy change | A |
| H | Standing active Global Admin | A |

A, B, C, H first. Then D, E. Then F, G.

---

## 7. Wave 3 reminder (Copilot, already designed)

When that audit cycle is due, reuse existing Copilot queries. Do not start a second program.

- Usage: already in S1 (`Microsoft Copilot`, `ActorName`, `LLMEventData.AccessedResources[*].Name`, zip/split for Action, `RawEventData.ClientIP`)
- Next: ingest silence, RecordTypes 310-325 and 384, collector consent, CUI/CHRI filename weekly review, Security Copilot vs SOC roster

---

## 8. Wave 5 reminder (CMMC L3)

L3 = L2 + 24 requirements from NIST SP 800-172 (Feb 2021) as listed in 32 CFR 170.14. For this SIEM program the extras that matter are: 24/7 (or on-call) ownership of alerts A-H; documented aperiodic hunting on the same S1 data; org-owned/compliant devices for admin and Copilot; annual pentest of the M365 control plane. Inventory and misconfiguration detection are ScubaGear + Intune/MDE, not a new lake.

---

## 9. Cadence after Wave 1

| When | Who | What |
|---|---|---|
| Each known GA/PRA change | Engineer | Confirm it still appears in the saved query |
| Weekly 30 min | Engineer + GRC | Group-by-actor vs tickets |
| After parser deploy | Engineer | Re-pin field names; do not assume `ActorName` |

---

## 10. Files in this folder

- This plan: `nist-simple/GCC-High-CONMON-Action-Plan.md`
- Copilot matrix: `Copilot-CONMON-NIST.xlsx` / `.ods`
- Copilot S1 queries: `nist-simple/s1-queries/`
- Wave 1 queries: `nist-simple/s1-queries/W1-00-find-entra.pq.txt`, `W1-01-ga-pra-list.pq.txt`, `W1-02-ga-pra-group.pq.txt`
